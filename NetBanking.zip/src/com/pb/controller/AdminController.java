package com.pb.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AdminController
 */
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String m_op=request.getParameter("op");
		String url =null;
		if(m_op.equals("updateprofile"))
		{
			url = "updateprofile.jsp";
		}else if(m_op.equals("changeAdminPassword"))
		{
			url = "changePassword.jsp";
		}else if(m_op.equals("updateCustPassword"))
		{
			url = "UpdateCustomerPassword.jsp";
		}
		else if(m_op.equals("display"))
		{
			url = "ViewCustomer.jsp";
		}
		else if(m_op.equals("addCustomer"))
		{
			url = "signup.html";
		}
		else if(m_op.equals("deleteCustomer"))
		{
			url = "DeleteCustomer.jsp";
		}
		else if(m_op.equals("approvals"))
		{
			url = "Approval.jsp";
		}
		else if(m_op.equals("logout"))
		{
			url = "LogOut";
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}

}
