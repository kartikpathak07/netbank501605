package com.pb.dao;

import java.util.ArrayList;
import java.util.List;

import com.pb.dto.Information;
import com.pb.dto.Login;

public interface LoginDao 
{
	String validate(String username,String password);
	String updatePassword(String m_dbpassword,String oldpassword,String newpassword,String verifypassword);
	boolean insertrec(Login log);
	long viewBalance(String username);
	public List<Information> updateProfile(String username);
}
