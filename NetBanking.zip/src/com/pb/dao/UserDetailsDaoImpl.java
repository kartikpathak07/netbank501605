package com.pb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pb.dto.Beneficiary;
import com.pb.dto.Information;
import com.pb.dto.UserDetails;
import com.pb.dto.UserInfo;
import com.pb.util.JdbcConnection;
//METHOD TO INSERT USER IN DATA BASE BY ADMIN
public class UserDetailsDaoImpl implements UserDetailsDao
{
	public boolean insertrec(UserDetails user) 
	{
		
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		PreparedStatement pst1=null;
		PreparedStatement pst2=null;
		String query1="SELECT * FROM BANKLOGIN WHERE USERNAME=?";
		try {
			pst=conn.prepareStatement(query1);
			pst.setString(1, user.getUsername());
			
			ResultSet rec=pst.executeQuery();
			System.out.println("In select bank login");
			if(rec.next()==true)
			{//NEED TO CREATE JSP TO DISLAY THIS
				System.out.println("USERNAME ALREADY EXIST");
			}
			else if(rec.next()==false)
			{
				
				
				
			
				System.out.println("iN INSERT BANK LOGIN");
				String query2="INSERT INTO BANKLOGIN VALUES(?,?,'user')";
				pst1=conn.prepareStatement(query2);
				pst1.setString(1, user.getUsername());
				pst1.setString(2, user.getPassword());
				int rec1=pst1.executeUpdate();
				
				
				
			
				if(rec1==1)
				{
					String query3="INSERT INTO BANKUSER VALUES(?,?,?,?,?,?,?,?)";
					
					System.out.println("in INSERT  BANKUER ");
					pst2=conn.prepareStatement(query3);
					pst2.setLong(1, user.getAccno());
					pst2.setString(2, user.getUsername());
					pst2.setString(3, user.getName());
					pst2.setLong(4, user.getBal());
					pst2.setString(5, user.getAtype());
					pst2.setString(6, user.getAddress());
					pst2.setLong(7, user.getContact());
					pst2.setString(8, user.getEmail());
					int rec2=pst2.executeUpdate();
				
					
					return true;
				}
			}
			else
			{
				System.out.println("USERNAME does  ALREADY EXIST");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return false;
	}
	
	
	//METHOD TO VIEW DETAILS OF USERS BY ADMIN 
	
	public List viewDetails() throws SQLException
	{
		
		
	List<UserInfo> b=new ArrayList<UserInfo>();
	Connection conn=null;
	try {
	
	conn=JdbcConnection.getConnection();
	String sql ="select * from BankUser BU,BANKLOGIN BL where BU.username=BL.username and role='user'";
	PreparedStatement pst = conn.prepareStatement(sql);
	
	ResultSet rs= pst.executeQuery();
	while(rs.next())
	{
		

		System.out.println("USER View ");
UserInfo b1=new UserInfo();

	b1.setAccount_no(rs.getLong(1));
	b1.setUsername(rs.getString(2));
	b1.setCustname(rs.getString(3));
	b1.setBalance(rs.getLong(4));
	b1.setAcctype(rs.getString(5));
	b1.setAddress(rs.getString(6));
	b1.setPhoneno(rs.getLong(7));
	b1.setEmail(rs.getString(8));
	b1.setPassword(rs.getString(10));
	b.add(b1);
	System.out.println(b1.toString());
	}
	} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	finally
	{
	try {
		conn.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	return b;
	}
	
	
	
	//METHOD TO DELETE CUSTOMERS BY ADMIN
	
	public int deleteCustomer(long accountno)
	{
		System.out.println(accountno);
		int i=0;
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		String query="DELETE FROM BANKUSER WHERE acc_no=?";
		System.out.println("HELLO");
		try {
			pst=conn.prepareStatement(query);

			pst.setLong(1, accountno);
			int check=pst.executeUpdate();
			if(check>0)
			{
				i=1;
			}
			else
			{
				i=0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		return i;
		
	}
	public List viewBalance(String username)
	{
		int i=0;
		List<UserInfo> b=new ArrayList<UserInfo>();
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		
		String sql ="select * from BankUser WHERE USERNAME=?";
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, username);
			ResultSet rs= pst.executeQuery();
			while(rs.next())
			{
				

				System.out.println("USER View ");
UserInfo b1=new UserInfo();

			b1.setAccount_no(rs.getLong(1));
			b1.setUsername(rs.getString(2));
			
			b1.setBalance(rs.getLong(4));
			b1.setAcctype(rs.getString(5));
			b.add(b1);
			System.out.println(b1.toString());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		return b;
	}
	
	

}


