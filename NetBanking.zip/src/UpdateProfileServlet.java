

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pb.dao.LoginDaoImpl;

/**
 * Servlet implementation class UpdateProfileServlet
 */
public class UpdateProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProfileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter(); 
		String m_custname=request.getParameter("custname");
		String m_address=request.getParameter("address");
		String m_email=request.getParameter("email");
		String mcontactno=request.getParameter("contactno");
		long m_contactno=Long.parseLong(mcontactno);
		HttpSession session =request.getSession(false);
		String m_dbname = (String) request.getSession().getAttribute("a_username");
		LoginDaoImpl ldao=new LoginDaoImpl();
		int check=ldao.updateProfileData(m_dbname, m_address, m_contactno, m_email);
		if(check==1)
		{
			if(ldao.differentiate(m_dbname)){
			out.print("PROFILE UPDATED SUCCESSFULLY");
			RequestDispatcher rd=request.getRequestDispatcher("AdminPage.jsp");
			rd.forward(request, response);
			}
			else{
				RequestDispatcher rd=request.getRequestDispatcher("UserPage.jsp");
				rd.forward(request, response);
				}
				
			}
		
		else
		{
			out.print("PROFILE UPDATED SUCCESSFULLY");
			RequestDispatcher rd=request.getRequestDispatcher("UserPage.jsp");
			rd.forward(request, response);
			
		}
	}

}
